**Simplified Sign** 

>Email and password based authentication 

>Authentication with Google SignIn

>Link Account with Google Sign In

>Simple Register-Login flow


**SignInTest** 

Email and password based authentication 

Firebase Examples

Note : Add google-services.json file in app module downloaded from Firebasse console
